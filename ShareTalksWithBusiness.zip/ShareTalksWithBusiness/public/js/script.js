// Основной скрипт для проекта
console.log('Welcome to ShareTalks with Business!');
