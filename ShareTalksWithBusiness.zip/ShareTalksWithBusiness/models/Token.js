const mongoose = require('mongoose');

const TokenSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'User', // Ссылка на модель пользователя
    },
    token: {
      type: String,
      required: true,
    },
    createdAt: {
      type: Date,
      default: Date.now,
      expires: 3600, // Токен будет автоматически удален через 1 час
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Token', TokenSchema);
