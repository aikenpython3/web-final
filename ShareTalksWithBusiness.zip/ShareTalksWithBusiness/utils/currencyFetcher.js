const axios = require('axios');

// Функция для получения курсов валют
exports.getCurrencyRates = async () => {
  try {
    const response = await axios.get(
      `https://api.exchangerate-api.com/v4/latest/USD`
    );
    const rates = response.data.rates;

    // Пример: выводим только курсы для EUR, KZT, RUB
    return {
      USD: rates.USD,
      EUR: rates.EUR,
      KZT: rates.KZT,
      RUB: rates.RUB,
    };
  } catch (error) {
    console.error('Error fetching currency rates:', error.message);
    return null;
  }
};
