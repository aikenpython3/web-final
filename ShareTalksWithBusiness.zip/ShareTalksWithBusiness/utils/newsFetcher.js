const axios = require('axios');

// Функция для получения бизнес-новостей
exports.getBusinessNews = async () => {
  try {
    const response = await axios.get(
      `https://newsapi.org/v2/top-headlines`, // Используем NewsAPI
      {
        params: {
          category: 'business',
          country: 'us', // Новости из США
          apiKey: process.env.NEWS_API_KEY, // Ключ API
        },
      }
    );

    const articles = response.data.articles;
    return articles.slice(0, 5); // Возвращаем 5 последних новостей
  } catch (error) {
    console.error('Error fetching business news:', error.message);
    return [];
  }
};
