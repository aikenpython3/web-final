// Middleware для проверки аутентификации
exports.ensureAuthenticated = (req, res, next) => {
    if (req.user) {
      return next();
    }
    res.redirect('/auth/login');
  };
  
  // Middleware для проверки роли администратора
  exports.ensureAdmin = (req, res, next) => {
    if (req.user && req.user.role === 'admin') {
      return next();
    }
    res.status(403).send('Access denied: Admins only');
  };
  