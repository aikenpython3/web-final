const rateLimit = require('express-rate-limit');

// Лимитируем количество запросов
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 минут
  max: 100, // Максимум 100 запросов за 15 минут
  message: 'Too many requests from this IP, please try again after 15 minutes',
});

module.exports = apiLimiter;
