const express = require('express');
const router = express.Router();
const postController = require('../controllers/postController');
const { ensureAuthenticated, ensureAdmin } = require('../middleware/auth');

// Показать все посты
router.get('/', postController.getAllPosts);

// Показать один пост
router.get('/:id', ensureAuthenticated, postController.getPostById);

// Создать пост (доступно только аутентифицированным пользователям)
router.get('/create', ensureAuthenticated, (req, res) => {
  return res.render('posts/add', { title: 'Create Post' });
});
router.post('/create', ensureAuthenticated, postController.createPost);

// Обновить пост (только автор или администратор)
router.get('/edit/:id', ensureAuthenticated, async (req, res) => {
  // Логика для отображения формы редактирования
  const post = await postController.getPostById(req, res);
  if (!post) return res.status(404).send('Post not found');
  return res.render('posts/update', { title: 'Edit Post', post });
});
router.put('/edit/:id', ensureAuthenticated, postController.updatePost);

// Удалить пост (только администратор)
router.delete('/:id', ensureAdmin, postController.deletePost);

module.exports = router;
