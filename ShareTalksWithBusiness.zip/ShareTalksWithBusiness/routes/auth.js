const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

// Страница регистрации
router.get('/register', (req, res) => {
  return res.render('auth/register', { title: 'Register' });
});

// Обработка регистрации
router.post('/register', authController.register);

// Страница входа
router.get('/login', (req, res) => {
  return res.render('auth/login', { title: 'Login' });
});

// Обработка входа
router.post('/login', authController.login);

// Выход из аккаунта
router.get('/logout', authController.logout);

module.exports = router;
