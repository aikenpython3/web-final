const express = require('express');
const router = express.Router();
const postController = require('../controllers/postController');
const { ensureAuthenticated } = require('../middleware/auth');
const { getCurrencyRates } = require('../utils/currencyFetcher');
const { getBusinessNews } = require('../utils/newsFetcher');


// Главная страница
router.get('/', async (req, res) => {
  try {
    const posts = await postController.getAllPosts(req, res, true); // Получаем все посты
    const currencyRates = await getCurrencyRates(); // Курсы валют
    const businessNews = await getBusinessNews(); // Бизнес-новости

    return res.render('home', { posts, currencyRates, businessNews });
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});

module.exports = router;
