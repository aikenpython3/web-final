const Post = require('../models/Post');
const { sendNotification } = require('./notification');

// Показать все посты
exports.getAllPosts = async (req, res) => {
  try {
    const posts = await Post.find()
      .populate('author', 'name') // Подгружаем только имя автора
      .sort({ createdAt: -1 }); // Сортируем по дате создания, новые сверху

    // Рендерим корректный шаблон и передаём title для layout
    return res.render('home', { posts, title: 'All Posts' });
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
};

// Показать один пост
exports.getPostById = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id).populate('author', 'name');
    if (!post) {
      return res.status(404).send('Post not found');
    }
    return res.render('posts/details', { title: 'post' }, { post });
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
};

// Создать новый пост
exports.createPost = async (req, res) => {
  try {
    const { title, description } = req.body;
    const author = req.user.id; // Получаем ID текущего пользователя

    if (!title || !description) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    const post = new Post({
      title,
      description,
      author,
    });

    await post.save();

    // Отправляем уведомление всем пользователям
    await sendNotification(
      'New Post Created!',
      `A new post titled "${title}" has been created. Check it out on ShareTalks with Business!`
    );

    res.redirect('/'); // Возвращаемся на главную страницу
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
};

// Обновить пост
exports.updatePost = async (req, res) => {
  try {
    const { title, description } = req.body;
    const post = await Post.findById(req.params.id);

    if (!post) {
      return res.status(404).send('Post not found');
    }

    // Проверяем, является ли пользователь автором или администратором
    if (post.author.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).send('Unauthorized');
    }

    post.title = title || post.title;
    post.description = description || post.description;

    await post.save();
    res.redirect('/');
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
};

// Удалить пост
exports.deletePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);

    if (!post) {
      return res.status(404).send('Post not found');
    }

    // Только администратор может удалять посты
    if (req.user.role !== 'admin') {
      return res.status(403).send('Unauthorized');
    }

    await post.remove();
    res.redirect('/');
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
};
