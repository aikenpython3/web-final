const nodemailer = require('nodemailer');
const User = require('../models/User');

// Настройка транспорта для отправки писем
const transporter = nodemailer.createTransport({
  service: 'Gmail',
  auth: {
    user: process.env.EMAIL_USER, // ваш email
    pass: process.env.EMAIL_PASS, // ваш пароль приложения
  },
});

// Функция для отправки уведомления
exports.sendNotification = async (subject, text) => {
  try {
    // Получаем всех пользователей
    const users = await User.find();

    // Формируем список email-адресов
    const recipientEmails = users.map(user => user.email);

    // Настройка письма
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: recipientEmails.join(','), // отправить всем пользователям
      subject,
      text,
    };

    // Отправляем письмо
    await transporter.sendMail(mailOptions);
    console.log('Notifications sent successfully!');
  } catch (error) {
    console.error('Error sending notifications:', error);
  }
};
