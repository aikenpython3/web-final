const User = require('../models/User');
const jwt = require('jsonwebtoken');

// Регистрация
exports.register = async (req, res) => {
  try {
    const { username, email, password } = req.body;

    // Проверка, что все поля заполнены
    if (!username || !email || !password) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    // Создаем нового пользователя
    const newUser = new User({ username, email, password });
    await newUser.save();

    res.redirect('/auth/login');
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
};

// Вход
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'User not found' });
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Генерация токена
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: '1d',
    });

    res.cookie('token', token, { httpOnly: true });
    res.redirect('/');
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
};

// Выход
exports.logout = (req, res) => {
  res.clearCookie('token');
  res.redirect('/');
};
